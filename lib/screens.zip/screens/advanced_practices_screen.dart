import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class AdvancedPracticesScreen extends StatefulWidget {
  @override
  _AdvancedPracticesScreenState createState() => _AdvancedPracticesScreenState();
}

class _AdvancedPracticesScreenState extends State<AdvancedPracticesScreen> {
  List<dynamic> practices = [];

  @override
  void initState() {
    super.initState();
    loadPractices();
  }

  Future<void> loadPractices() async {
    final data = await rootBundle.loadString('assets/advanced_practices.json');
    setState(() {
      practices = json.decode(data);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Advanced Practices")),
      body: ListView.builder(
        itemCount: practices.length,
        itemBuilder: (context, index) {
          final item = practices[index];
          return Card(
            child: ListTile(
              title: Text(item['title']),
              subtitle: Text(item['description']),
              trailing: Text(item['duration']),
            ),
          );
        },
      ),
    );
  }
}