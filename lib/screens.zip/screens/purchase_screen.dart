import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../services/razorpay_service.dart';
import 'ritual_confirmation_screen.dart';
import '../services/payment_handler.dart';
import 'individual_portal_screen.dart';

class PurchaseScreen extends StatefulWidget {
  const PurchaseScreen({Key? key}) : super(key: key);

  @override
  State<PurchaseScreen> createState() => _PurchaseScreenState();
}

class _PurchaseScreenState extends State<PurchaseScreen> {
  final RazorpayService _razorpayService = RazorpayService();
  final User? user = FirebaseAuth.instance.currentUser;

  final List<int> portalPrices = [199, 249, 299, 349, 399, 449, 499, 499];
  final int bundlePrice = 1899;

  @override
  void initState() {
    super.initState();
    _razorpayService.init(_handlePaymentSuccess, _handlePaymentError);
  }

  @override
  void dispose() {
    _razorpayService.dispose();
    super.dispose();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final unlocks = [
      ...List.generate(8, (i) => 'portal_${i + 1}'),
      'portal_infinity',
      'ritual_bonus_1',
      'ritual_bonus_2',
      'wallpaper_pack',
      'cosmic_theme',
      'advanced_practices',
      'infinite_scroll',
    ];

    debugPrint('✅ Razorpay success: ${response.paymentId}');
    await handlePaymentSuccess(context: context, unlocks: unlocks);
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('⚠️ Payment failed: ${response.message}')),
    );
  }

  void _startBundlePurchase() {
    final razorpayKey = dotenv.env['RAZORPAY_KEY_ID'];
    if (razorpayKey == null || razorpayKey.isEmpty) {
      debugPrint('⚠️ Razorpay key missing in .env');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Razorpay key missing. Please check .env')),
      );
      return;
    }

    final amountInPaise = bundlePrice * 100;

    debugPrint('🛒 Starting bundle purchase');
    debugPrint('🔑 Razorpay Key: $razorpayKey');
    debugPrint('💰 Amount in Paise: $amountInPaise');

    _razorpayService.openCheckout(
      keyId: razorpayKey,
      amount: amountInPaise,
      name: 'Portal8 Cosmic Bundle',
    );
  }

  Widget _portalSwiper() {
    return SizedBox(
      height: 180,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: portalPrices.length,
        itemBuilder: (context, index) {
          final portalNumber = index + 1;
          final price = portalPrices[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => IndividualPortalScreen(
                    portalIndex: portalNumber,
                    price: price,
                  ),
                ),
              );
            },
            child: Container(
              width: 140,
              margin: const EdgeInsets.symmetric(horizontal: 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.deepPurpleAccent, Colors.indigo],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black45, blurRadius: 8, offset: Offset(0, 4))],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Portal $portalNumber', style: const TextStyle(color: Colors.white, fontSize: 18)),
                  const SizedBox(height: 8),
                  Text('₹$price', style: const TextStyle(color: Colors.white70, fontSize: 16)),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => IndividualPortalScreen(
                            portalIndex: portalNumber,
                            price: price,
                          ),
                        ),
                      );
                    },
                    child: const Text('Buy'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purpleAccent,
                      minimumSize: const Size(100, 36),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _benefit(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        text,
        style: const TextStyle(fontSize: 16, color: Colors.white70),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalIndividual = portalPrices.reduce((a, b) => a + b);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('✨ Unlock Your Awakening'),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Text(
                '🪐 Choose Your Path',
                style: TextStyle(
                  fontSize: 26,
                  color: Colors.purpleAccent,
                  fontWeight: FontWeight.bold,
                  shadows: [Shadow(blurRadius: 12, color: Colors.purple, offset: Offset(0, 0))],
                ),
              ),
            ),
            const SizedBox(height: 32),
            _portalSwiper(),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.indigo.shade900,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('🌌 Cosmic Bundle – ₹$bundlePrice',
                      style: const TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(
                    'Includes all 8 portals, rituals, wallpapers, premium theme\n'
                        '+ Lifetime access to Advanced Practices & Infinite Scroll\n'
                        '(Save ₹${totalIndividual - bundlePrice})',
                    style: const TextStyle(fontSize: 16, color: Colors.white70),
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _startBundlePurchase,
                      icon: const Icon(Icons.lock_open),
                      label: const Text('Unlock Bundle'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purpleAccent,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                        textStyle: const TextStyle(fontSize: 18),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                        elevation: 8,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            const Text(
              "🌟 Why Begin?",
              style: TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            _benefit("🌿 Deep relaxation and inner peace"),
            _benefit("✨ Bliss beyond thought and form"),
            _benefit("🛡️ Freedom from anxiety and depression"),
            _benefit("🌞 A life lived fully, not just survived"),
            _benefit("🌀 A mythic journey that evolves with you"),
          ],
        ),
      ),
    );
  }
}