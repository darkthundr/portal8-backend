import 'package:flutter/material.dart';

class InfinityScrollScreen extends StatelessWidget {
  const InfinityScrollScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Text(
          "∞ Infinity Scroll ∞",
          style: TextStyle(fontSize: 24, color: Colors.white),
        ),
      ),
    );
  }
}