import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// You'll need to create this file or replace `LoginScreen()` with your actual login page widget.
import 'package:portal8/screens/login_screen.dart';


class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: Text("Login Screen")));
  }
}


// --- Data Model ---
class UserProfileData {
  final String name;
  final String email;
  final String joined;
  final bool hasBundle;
  final bool allPortalsUnlocked;
  final bool infiniteScroll;

  UserProfileData({
    this.name = "Seeker",
    this.email = "",
    this.joined = "",
    this.hasBundle = false,
    this.allPortalsUnlocked = false,
    this.infiniteScroll = false,
  });
}

// --- Main Screen ---
class ProfileSettingsScreen extends StatefulWidget {
  const ProfileSettingsScreen({super.key});

  @override
  State<ProfileSettingsScreen> createState() => _ProfileSettingsScreenState();
}

class _ProfileSettingsScreenState extends State<ProfileSettingsScreen> {
  UserProfileData? _userData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final data = doc.data();

      if (data != null) {
        final hasBundle = data['hasBundle'] ?? false;
        final allPortalsUnlocked = data['allPortalsUnlocked'] ?? false;
        _userData = UserProfileData(
          name: data['name'] ?? user.displayName ?? "Seeker",
          email: data['email'] ?? user.email ?? "",
          joined: _formatTimestamp(data['joined']),
          hasBundle: hasBundle,
          allPortalsUnlocked: allPortalsUnlocked,
          infiniteScroll: data['infiniteScroll'] ?? (hasBundle || allPortalsUnlocked),
        );
      } else {
        _userData = UserProfileData(email: user.email ?? "");
      }
    } catch (e) {
      _userData = UserProfileData(email: user.email ?? "", name: "Error Loading");
    }

    if (mounted) setState(() => _isLoading = false);
  }

  String _formatTimestamp(dynamic ts) {
    if (ts is Timestamp) {
      final date = ts.toDate();
      return "${date.day}/${date.month}/${date.year}";
    }
    return "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0B1E),
      body: SafeArea(
        child: _isLoading
            ? const Center(child: CircularProgressIndicator(color: Colors.purpleAccent))
            : _userData == null
            ? const Center(child: Text("Could not load profile.", style: TextStyle(color: Colors.white70)))
            : ListView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          children: [
            _ProfileHeader(
              name: _userData!.name,
              email: _userData!.email,
              joined: _userData!.joined,
              hasBundle: _userData!.hasBundle,
              allPortalsUnlocked: _userData!.allPortalsUnlocked,
              infiniteScroll: _userData!.infiniteScroll,
            ),
            const SizedBox(height: 30),
            _PurchaseStatus(
              hasBundle: _userData!.hasBundle,
              allPortalsUnlocked: _userData!.allPortalsUnlocked,
              infiniteScroll: _userData!.infiniteScroll,
            ),
            const SizedBox(height: 30),
            const _SettingsSection(),
            const SizedBox(height: 40),
            const _AccountActions(),
          ],
        ),
      ),
    );
  }
}

// --- Profile Header ---
class _ProfileHeader extends StatefulWidget {
  final String name;
  final String email;
  final String joined;
  final bool hasBundle;
  final bool allPortalsUnlocked;
  final bool infiniteScroll;

  const _ProfileHeader({
    required this.name,
    required this.email,
    required this.joined,
    required this.hasBundle,
    required this.allPortalsUnlocked,
    required this.infiniteScroll,
    super.key,
  });

  @override
  State<_ProfileHeader> createState() => _ProfileHeaderState();
}

class _ProfileHeaderState extends State<_ProfileHeader> with TickerProviderStateMixin {
  late AnimationController _glowController;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Color _auraColor() {
    if (widget.allPortalsUnlocked) return Colors.purpleAccent;
    if (widget.hasBundle || widget.infiniteScroll) return Colors.blueAccent.withOpacity(0.6);
    return Colors.white24;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _glowController,
          builder: (context, __) {
            return Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _auraColor().withOpacity(0.5 + 0.5 * _glowController.value),
                    blurRadius: 30 + 10 * _glowController.value,
                    spreadRadius: 4 + 2 * _glowController.value,
                  ),
                ],
              ),
              child: const CircleAvatar(
                radius: 40,
                backgroundColor: Colors.purpleAccent,
                child: Icon(Icons.person, size: 40, color: Colors.white),
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        Text(
          widget.name,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 4),
        Text(
          widget.email,
          style: const TextStyle(fontSize: 14, color: Colors.white70),
        ),
        if (widget.joined.isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(
            "Joined on ${widget.joined}",
            style: const TextStyle(fontSize: 14, color: Colors.white38),
          ),
        ],
      ],
    );
  }
}

// --- Purchase Status ---
class _PurchaseStatus extends StatelessWidget {
  final bool hasBundle;
  final bool allPortalsUnlocked;
  final bool infiniteScroll;

  const _PurchaseStatus({
    required this.hasBundle,
    required this.allPortalsUnlocked,
    required this.infiniteScroll,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Your Unlocks",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 12),
        _statusTile("Bundle Purchased", hasBundle),
        _statusTile("All Portals Unlocked", allPortalsUnlocked),
        _statusTile("∞ Scroll Access", infiniteScroll),
      ],
    );
  }

  Widget _statusTile(String label, bool status) {
    return ListTile(
      leading: Icon(
        status ? Icons.check_circle : Icons.lock_outline,
        color: status ? Colors.greenAccent : Colors.white38,
      ),
      title: Text(
        label,
        style: TextStyle(
          color: status ? Colors.white : Colors.white54,
          fontSize: 16,
        ),
      ),
    );
  }
}

// --- Settings Section ---
class _SettingsSection extends StatelessWidget {
  const _SettingsSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Settings",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          value: true, // This should be tied to a state variable
          onChanged: (val) {
            // TODO: Implement theme toggle logic
          },
          title: const Text("Dark Theme", style: TextStyle(color: Colors.white)),
          activeColor: Colors.purpleAccent,
        ),
        SwitchListTile(
          value: true, // This should be tied to a state variable
          onChanged: (val) {
            // TODO: Implement notification toggle logic
          },
          title: const Text("Notifications", style: TextStyle(color: Colors.white)),
          activeColor: Colors.purpleAccent,
        ),
      ],
    );
  }
}

// --- Account Actions ---
class _AccountActions extends StatelessWidget {
  const _AccountActions({super.key});

  // Handles signing out the user
  Future<void> _logOut(BuildContext context) async {
    await FirebaseAuth.instance.signOut();
    if (context.mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
            (route) => false,
      );
    }
  }

  // Handles the entire account deletion flow
  Future<void> _deleteAccount(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email == null) {
      // Cannot proceed if there's no user or email
      return;
    }

    try {
      // 1. Prompt for password to re-authenticate (for security)
      final password = await _promptPassword(context);
      if (password == null) return; // User cancelled

      // 2. Re-authenticate the user
      final cred = EmailAuthProvider.credential(email: user.email!, password: password);
      await user.reauthenticateWithCredential(cred);

      // 3. Delete Firestore data
      await FirebaseFirestore.instance.collection('users').doc(user.uid).delete();

      // 4. Delete the Firebase Auth user
      await user.delete();

      // 5. Navigate to the login screen
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
              (route) => false,
        );
      }
    } on FirebaseAuthException catch (e) {
      if (context.mounted) {
        // Show an error message if anything goes wrong
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: ${e.message}")),
        );
      }
    }
  }

  // Helper dialog to securely get the user's password
  Future<String?> _promptPassword(BuildContext context) {
    String? password;
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1B1833),
          title: const Text("Enter Password to Confirm", style: TextStyle(color: Colors.white)),
          content: TextField(
            obscureText: true,
            onChanged: (val) => password = val,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: "Password",
              labelStyle: TextStyle(color: Colors.white70),
              focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.purpleAccent)),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: const Text("Cancel", style: TextStyle(color: Colors.white)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, password),
              child: const Text("Confirm", style: TextStyle(color: Colors.purpleAccent)),
            ),
          ],
        );
      },
    );
  }

  // Helper dialog to confirm the deletion action
  void _confirmDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1B1833),
        title: const Text("Delete Account?", style: TextStyle(color: Colors.white)),
        content: const Text(
          "This action is permanent and cannot be undone.",
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel", style: TextStyle(color: Colors.white)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close confirmation dialog
              // Show fade overlay then start the deletion process
              showDialog(
                context: context,
                barrierDismissible: false,
                builder: (_) => RitualFadeOverlay(
                  onComplete: () => _deleteAccount(context),
                ),
              );
            },
            child: const Text("Delete", style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
  }

  // Reusable button style
  ButtonStyle _buttonStyle({Color background = Colors.purpleAccent}) {
    return ElevatedButton.styleFrom(
      backgroundColor: background,
      foregroundColor: Colors.white,
      minimumSize: const Size(double.infinity, 50),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton.icon(
          onPressed: () {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => RitualFadeOverlay(
                onComplete: () => _logOut(context),
              ),
            );
          },
          icon: const Icon(Icons.logout),
          label: const Text("Log Out"),
          style: _buttonStyle(),
        ),
        const SizedBox(height: 16),
        ElevatedButton.icon(
          onPressed: () => _confirmDeleteDialog(context),
          icon: const Icon(Icons.delete_forever),
          label: const Text("Delete Account"),
          style: _buttonStyle(background: Colors.redAccent),
        ),
      ],
    );
  }
}

// --- Overlay Widget ---
class RitualFadeOverlay extends StatefulWidget {
  final VoidCallback onComplete;

  const RitualFadeOverlay({required this.onComplete, super.key});

  @override
  State<RitualFadeOverlay> createState() => _RitualFadeOverlayState();
}

class _RitualFadeOverlayState extends State<RitualFadeOverlay> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 1));
    _opacity = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _controller.forward().whenComplete(() {
      // Pop the overlay itself before running the completion callback
      Navigator.of(context).pop();
      widget.onComplete();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _opacity,
      child: Container(
        color: Colors.black.withOpacity(0.9),
        child: const Center(
          child: Icon(Icons.auto_awesome, size: 80, color: Colors.purpleAccent),
        ),
      ),
    );
  }
}