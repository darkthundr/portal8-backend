import 'package:flutter/material.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../services/razorpay_service.dart';
import 'ritual_confirmation_screen.dart';
import '../services/payment_handler.dart';

class IndividualPortalScreen extends StatefulWidget {
  final int portalIndex;
  final int price;

  const IndividualPortalScreen({super.key, required this.portalIndex, required this.price});

  @override
  State<IndividualPortalScreen> createState() => _IndividualPortalScreenState();
}

class _IndividualPortalScreenState extends State<IndividualPortalScreen> {
  final RazorpayService _razorpayService = RazorpayService();
  final User? user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _razorpayService.init(_handlePaymentSuccess, _handlePaymentError);
  }

  @override
  void dispose() {
    _razorpayService.dispose();
    super.dispose();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final portalId = 'portal_${widget.portalIndex}';
    debugPrint('✅ Razorpay success: ${response.paymentId}');
    await handlePaymentSuccess(context: context, unlocks: [portalId]);
  }
  void _handlePaymentError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('⚠️ Payment failed: ${response.message}')),
    );
  }

  void _startPortalPurchase() {
    final razorpayKey = dotenv.env['RAZORPAY_KEY_ID'];
    if (razorpayKey == null || razorpayKey.isEmpty) {
      debugPrint('⚠️ Razorpay key missing in .env');
      return;
    }

    final amountInPaise = widget.price * 100;

    _razorpayService.openCheckout(
      keyId: razorpayKey,
      amount: amountInPaise,
      name: 'Portal ${widget.portalIndex} Unlock',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Portal ${widget.portalIndex}'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 40),
            Text(
              '🌀 Unlock Portal ${widget.portalIndex}',
              style: const TextStyle(fontSize: 24, color: Colors.purpleAccent, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(
              'Price: ₹${widget.price}',
              style: const TextStyle(fontSize: 18, color: Colors.white70),
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _startPortalPurchase,
              icon: const Icon(Icons.lock_open),
              label: const Text('Unlock Now'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purpleAccent,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                textStyle: const TextStyle(fontSize: 18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                elevation: 8,
              ),
            ),
          ],
        ),
      ),
    );
  }
}