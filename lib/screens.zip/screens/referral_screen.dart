import 'package:flutter/material.dart';
import 'package:portal8/utils/app_constants.dart'; // Import for consistent styling
import 'package:portal8/utils/starfield_background.dart'; // For background

class ReferralScreen extends StatelessWidget {
  const ReferralScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          "Cosmic Referrals",
          style: kTitleTextStyle.copyWith(
            fontSize: screenSize.width * 0.05,
            shadows: const [
              Shadow(
                color: Colors.blue,
                blurRadius: 8.0,
              ),
            ],
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          const Positioned.fill(child: StarfieldBackground()),
          Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + kToolbarHeight + 20,
                bottom: 20,
                left: screenSize.width * 0.05,
                right: screenSize.width * 0.05,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Expand the Cosmic Collective",
                    textAlign: TextAlign.center,
                    style: kTitleTextStyle.copyWith(
                      fontSize: screenSize.width * 0.065,
                      shadows: const [
                        Shadow(
                          color: Colors.purpleAccent,
                          blurRadius: 20.0,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: screenSize.height * 0.02),
                  Text(
                    "Invite fellow seekers to Portal 8 and accelerate their awakening journey.",
                    textAlign: TextAlign.center,
                    style: kSubtitleTextStyle.copyWith(color: kStarlightBlue),
                  ),
                  SizedBox(height: screenSize.height * 0.05),
                  Container(
                    padding: const EdgeInsets.all(25),
                    decoration: BoxDecoration(
                      color: kDeepSpacePurple.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: kCosmicCyan.withOpacity(0.6), width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: kCosmicCyan.withOpacity(0.3),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Icon(Icons.share_rounded, color: kAccentNeonGreen, size: screenSize.width * 0.15),
                        SizedBox(height: screenSize.height * 0.02),
                        Text(
                          "Your Unique Referral Code:",
                          style: kBodyTextStyle.copyWith(fontSize: screenSize.width * 0.04, color: Colors.white70),
                        ),
                        SizedBox(height: screenSize.height * 0.01),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: kStarlightBlue.withOpacity(0.5)),
                          ),
                          child: Text(
                            "COSMICAWAKENING8", // Placeholder referral code
                            style: kTitleTextStyle.copyWith(
                              fontSize: screenSize.width * 0.05,
                              color: kNebulaWhite,
                              letterSpacing: 1.5,
                              shadows: const [Shadow(color: Colors.cyanAccent, blurRadius: 8)],
                            ),
                          ),
                        ),
                        SizedBox(height: screenSize.height * 0.03),
                        ElevatedButton.icon(
                          onPressed: () {
                            // Implement copy to clipboard functionality
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Referral code copied!', style: kBodyTextStyle)),
                            );
                            // In a real app, you'd use:
                            // Clipboard.setData(const ClipboardData(text: "COSMICAWAKENING8"));
                          },
                          icon: Icon(Icons.copy_rounded, color: kCosmicBlack, size: screenSize.width * 0.05),
                          label: Text(
                            "Copy Code",
                            style: kBodyTextStyle.copyWith(fontSize: screenSize.width * 0.04, color: kCosmicBlack),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kAccentNeonGreen, // Vibrant button color
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            padding: EdgeInsets.symmetric(horizontal: screenSize.width * 0.06, vertical: 15),
                            shadowColor: kAccentNeonGreen.withOpacity(0.5),
                            elevation: 10,
                          ),
                        ),
                        SizedBox(height: screenSize.height * 0.02),
                        Text(
                          "Share this code with friends and unlock cosmic rewards!",
                          textAlign: TextAlign.center,
                          style: kBodyTextStyle.copyWith(fontSize: screenSize.width * 0.035, color: Colors.white54),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
