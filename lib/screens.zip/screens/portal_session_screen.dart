import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';

class Portal0SessionScreen extends StatelessWidget {
  const Portal0SessionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orbitron = GoogleFonts.orbitron(
      textStyle: const TextStyle(color: Colors.white, letterSpacing: 1.2),
    );

    return Scaffold(
      backgroundColor: const Color(0xFF0B0C2A),
      body: Stack(
        children: [
          // Background gradient
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0, -0.5),
                  radius: 1.2,
                  colors: [
                    Color(0xFF1A237E),
                    Color(0xFF0B0C2A),
                  ],
                ),
              ),
            ),
          ),

          // Content
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: PageView(
                physics: const BouncingScrollPhysics(),
                children: [

                  // 🧠 Pain Recognition Slide
                  FadeInUp(
                    duration: const Duration(milliseconds: 1000),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Looped Inside...', style: orbitron.copyWith(fontSize: 26)),
                        const SizedBox(height: 20),
                        Text(
                          'Wake up. Phone. Scroll.\nEat. Talk. Numb. Sleep.\nRepeat.',
                          style: GoogleFonts.openSans(
                            fontSize: 18,
                            color: Colors.white70,
                            height: 1.6,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 30),
                        Text(
                          'But something inside...\nwants **more**.',
                          style: GoogleFonts.openSans(
                            fontSize: 18,
                            color: Colors.blue[200],
                            fontWeight: FontWeight.bold,
                            height: 1.6,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),

                  // 🧬 Sensory Awareness Slide
                  FadeInUp(
                    duration: const Duration(milliseconds: 1000),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Feel This Moment', style: orbitron.copyWith(fontSize: 26)),
                        const SizedBox(height: 20),
                        Text(
                          'Close your eyes for 10 seconds.\nFeel your body.\nNotice the silence behind your thoughts.',
                          style: GoogleFonts.openSans(
                            fontSize: 18,
                            color: Colors.white70,
                            height: 1.6,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 30),
                        Text(
                          'That stillness...\nThat’s not “nothing”.\nThat’s where the **Cosmos** begins.',
                          style: GoogleFonts.openSans(
                            fontSize: 18,
                            color: Colors.blue[200],
                            fontWeight: FontWeight.bold,
                            height: 1.6,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),

                  // 🌌 Craving + Cliffhanger Slide
                  FadeInUp(
                    duration: const Duration(milliseconds: 1000),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('The Matrix Cracks...', style: orbitron.copyWith(fontSize: 26)),
                        const SizedBox(height: 20),
                        Text(
                          'You just felt a small part of what you truly are.\n\nThe journey beyond identity,\nbeyond thoughts,\nbeyond suffering...\nhas begun.',
                          style: GoogleFonts.openSans(
                            fontSize: 18,
                            color: Colors.white70,
                            height: 1.6,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 30),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: const Color(0xFF0C0C1E),
                            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          onPressed: () {
                            // Navigate to next (buy or unlock Portal 1)
                          },
                          child: Text(
                            'Unlock Portal 1 →',
                            style: orbitron.copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
