import 'package:flutter/material.dart';
import 'cosmic_nexus_screen.dart';
import 'purchase_screen.dart';
import 'infinity_scroll_screen.dart';
import 'profile_settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  bool get isInfiniteScrollUnlocked {
    // Replace with real unlock logic
    // e.g. UserPurchaseManager.hasBundle || UserPurchaseManager.allPortalsUnlocked
    return true; // ← simulate unlocked for now
  }

  List<Widget> get _screens => [
    const CosmicNexusScreen(),       // 🌌 Main portal grid
    const PurchaseScreen(),          // 🛍️ Purchase flow
    isInfiniteScrollUnlocked
        ? const InfinityScrollScreen() // 🔁 Bonus feature
        : const LockedScrollPlaceholder(),
    const ProfileSettingsScreen(),   // 👤 Profile + ⚙️ Settings
  ];

  final List<BottomNavigationBarItem> _bottomNavItems = const [
    BottomNavigationBarItem(
      icon: Icon(Icons.auto_awesome),
      label: 'Nexus',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.shopping_bag),
      label: 'Purchase',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.all_inclusive),
      label: '∞ Scroll',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.person),
      label: 'Profile',
    ),
  ];

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: IndexedStack(
            key: ValueKey<int>(_selectedIndex),
            index: _selectedIndex,
            children: _screens,
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: _bottomNavItems,
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        selectedItemColor: Colors.amberAccent,
        unselectedItemColor: Colors.white70,
        backgroundColor: const Color(0xFF1B1833),
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}

class LockedScrollPlaceholder extends StatelessWidget {
  const LockedScrollPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: const [
          Icon(Icons.lock, size: 60, color: Colors.white54),
          SizedBox(height: 16),
          Text(
            "∞ Scroll unlocks after completing all portals or purchasing the bundle.",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, fontSize: 16),
          ),
        ],
      ),
    );
  }
}