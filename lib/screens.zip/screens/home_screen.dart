import 'package:flutter/material.dart';
import 'dart:math';
import 'signup_screen.dart'; // Make sure this exists

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // 🌌 Cosmic Background
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  colors: [Color(0xFF6A00FF), Colors.black],
                  radius: 1.4,
                  center: Alignment(0.0, -0.3),
                ),
              ),
            ),
          ),

          // ✨ Floating Glyphs (simulated)
          Positioned.fill(
            child: CustomPaint(
              painter: ConstellationPainter(),
            ),
          ),

          // 🧠 Poetic Invocation
          Positioned(
            top: 120,
            left: 30,
            right: 30,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: const [
                RitualText(
                  text: "Awaken Through Portals",
                  delay: Duration(milliseconds: 500),
                ),
                SizedBox(height: 12),
                RitualText(
                  text: "Each portal reveals a truth.",
                  delay: Duration(seconds: 1),
                ),
                RitualText(
                  text: "Complete the journey. Unlock the infinite.",
                  delay: Duration(seconds: 2),
                ),
              ],
            ),
          ),

          // 🧭 Dashboard Button with Glow
          Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 220,
                  height: 70,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(35),
                    gradient: RadialGradient(
                      colors: [Colors.purpleAccent.withOpacity(0.3), Colors.transparent],
                      radius: 0.8,
                    ),
                  ),
                ),
                _glassButton(
                  label: "🧭 Go to Dashboard",
                  onTap: () {
                    Navigator.pushNamed(context, '/dashboard');
                  },
                ),
              ],
            ),
          ),

          // ✨ Begin Journey Button with Shimmer and Fade

        ],
      ),
    );
  }

  Widget _glassButton({required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 20),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.08),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(
              color: Colors.white.withOpacity(0.2),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.purpleAccent.withOpacity(0.5),
                blurRadius: 40,
                offset: const Offset(0, 12),
              ),
            ],
          ),
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _shimmerButton({required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: ShaderMask(
        shaderCallback: (bounds) {
          return LinearGradient(
            colors: [Colors.purpleAccent, Colors.blueAccent, Colors.pinkAccent],
            tileMode: TileMode.mirror,
          ).createShader(bounds);
        },
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.white,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }

  PageRouteBuilder _fadeRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, animation, __, child) {
        return FadeTransition(
          opacity: animation,
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 800),
    );
  }
}

class RitualText extends StatefulWidget {
  final String text;
  final Duration delay;

  const RitualText({super.key, required this.text, required this.delay});

  @override
  State<RitualText> createState() => _RitualTextState();
}

class _RitualTextState extends State<RitualText> with TickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );

    Future.delayed(widget.delay, () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() => _controller.dispose();

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _controller,
      child: Text(
        widget.text,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontSize: 18,
          color: Colors.white70,
          fontStyle: FontStyle.italic,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class ConstellationPainter extends CustomPainter {
  final Random _random = Random();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.08)
      ..style = PaintingStyle.fill;

    for (int i = 0; i < 80; i++) {
      final x = _random.nextDouble() * size.width;
      final y = _random.nextDouble() * size.height;
      final radius = _random.nextDouble() * 2 + 0.5;
      canvas.drawCircle(Offset(x, y), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}