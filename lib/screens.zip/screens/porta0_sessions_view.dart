import 'package:flutter/material.dart';
import 'portal0_session1.dart'; // Example session
import 'portal0_session2.dart'; // Add more as needed

class Portal0SessionsView extends StatelessWidget {
  const Portal0SessionsView({super.key});

  @override
  Widget build(BuildContext context) {
    final sessions = [
      {"title": "Session 1", "widget": const Portal0Session1()},
      {"title": "Session 2", "widget": const Portal0Session2()},
      // Add more sessions here
    ];

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: const Text("Portal 0: Sessions")),
      body: PageView.builder(
        itemCount: sessions.length,
        itemBuilder: (context, index) {
          final session = sessions[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => session["widget"] as Widget,
              ));
            },
            child: Container(
              margin: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [Colors.deepPurple.shade800, Colors.black],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: Text(
                  session["title"]!,
                  style: const TextStyle(fontSize: 24, color: Colors.tealAccent),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}