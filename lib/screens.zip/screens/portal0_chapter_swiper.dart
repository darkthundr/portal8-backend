import 'package:flutter/material.dart';
import '../data/portal0_chapters.dart';
import '../models/chapter_model.dart';
import 'chapter_detail_screen.dart';

class Portal0ChapterSwiper extends StatelessWidget {
  const Portal0ChapterSwiper({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: const Text("Portal 0: Rituals")),
      body: PageView.builder(
        itemCount: portal0Chapters.length,
        itemBuilder: (context, index) {
          final LegacyChapter chapter = portal0Chapters[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => ChapterDetailScreen(chapter: chapter),
              ));
            },
            child: Container(
              margin: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [Colors.deepPurple.shade800, Colors.black],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      chapter.title,
                      style: const TextStyle(fontSize: 24, color: Colors.tealAccent),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      chapter.teaser,
                      style: const TextStyle(fontSize: 16, color: Colors.white70),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      "Tap to enter ritual →",
                      style: TextStyle(fontSize: 14, color: Colors.white54),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}