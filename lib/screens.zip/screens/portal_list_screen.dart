import 'package:flutter/material.dart';
import '../widgets/locked_portal_card.dart';
import '../widgets/animated_chapter_card.dart';
import '../services/session_loader.dart';

class PortalListScreen extends StatefulWidget {
  const PortalListScreen({super.key});

  @override
  State<PortalListScreen> createState() => _PortalListScreenState();
}

class _PortalListScreenState extends State<PortalListScreen> {
  List<Map<String, dynamic>> portalData = [];

  @override
  void initState() {
    super.initState();
    loadPortals();
  }

  Future<void> loadPortals() async {
    final loader = SessionLoader();
    final data = await loader.loadSessionData();
    setState(() {
      portalData = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    final mainPortals = portalData.where((p) =>
    p['id'].startsWith('portal_') &&
        p['id'] != 'portal_infinity').toList();

    final bonusPortals = portalData.where((p) =>
    p['id'] == 'portal_infinity' ||
        p['id'].startsWith('ritual_') ||
        p['id'].startsWith('wallpaper_') ||
        p['id'] == 'cosmic_theme').toList();

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("🌀 Portals"),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text("Main Portals",
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.amberAccent,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...mainPortals.map((portal) => _buildPortalCard(portal)),

          const SizedBox(height: 24),
          const Text("Bonus Content",
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.lightBlueAccent,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...bonusPortals.map((portal) => _buildPortalCard(portal)),
        ],
      ),
    );
  }

  Widget _buildPortalCard(Map<String, dynamic> portal) {
    final isUnlocked = portal['unlocked'] == true;
    final id = portal['id'];
    final title = portal['title'];
    final subtitle = portal['subtitle'];
    final image = portal['image'];

    return isUnlocked
        ? AnimatedChapterCard(
      portalId: id,
      title: title,
      subtitle: subtitle,
      imageAsset: image,
    )
        : LockedPortalCard(
      portalId: id,
      title: title,
      subtitle: subtitle,
      imageAsset: image,
    );
  }
}