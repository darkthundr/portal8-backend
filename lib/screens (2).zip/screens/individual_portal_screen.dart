import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../services/payment_handler.dart';
import '../services/razorpay_service.dart';
import 'cosmic_nexus_screen.dart';
import 'infinity_invocation_screen.dart';

class IndividualPortalScreen extends StatefulWidget {
  final int portalIndex;
  final int price;

  const IndividualPortalScreen({
    Key? key,
    required this.portalIndex,
    required this.price,
  }) : super(key: key);

  @override
  State<IndividualPortalScreen> createState() => _IndividualPortalScreenState();
}

class _IndividualPortalScreenState extends State<IndividualPortalScreen> {
  bool _isLoading = true;
  bool _isUnlocked = false;
  final RazorpayService _razorpayService = RazorpayService();
  final user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _checkUnlocked();
    _razorpayService.init(
      onSuccess: _onPaymentSuccess,
      onError: _onPaymentError,
    );
  }

  Future<void> _checkUnlocked() async {
    if (user == null) return;
    _isUnlocked = await hasUnlocked("portal_${widget.portalIndex}");
    setState(() => _isLoading = false);
  }

  Future<void> _onPaymentSuccess(PaymentSuccessResponse response) async {
    if (user == null) return;

    final uid = user!.uid;
    final portalId = "portal_${widget.portalIndex}";
    final amount = widget.price;
    final timestamp = DateTime.now().toIso8601String();

    final userDoc = FirebaseFirestore.instance.collection('users').doc(uid);

    await FirebaseFirestore.instance.runTransaction((transaction) async {
      final snapshot = await transaction.get(userDoc);
      final data = snapshot.data() ?? {};

      final unlocked = List<String>.from(data['unlockedPortals'] ?? []);
      if (!unlocked.contains(portalId)) {
        unlocked.add(portalId);
      }

      final history = List<Map<String, dynamic>>.from(data['paymentHistory'] ?? []);
      history.add({
        'portalId': portalId,
        'amount': amount,
        'date': timestamp,
      });

      transaction.update(userDoc, {
        'unlockedPortals': unlocked,
        'paymentHistory': history,
      });
    });

    setState(() => _isUnlocked = true);

    if (widget.portalIndex == 999) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const InfinityInvocationScreen()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const CosmicNexusScreen()),
      );
    }
  }

  void _onPaymentError(PaymentFailureResponse response) {
    debugPrint('❌ Payment failed: ${response.message}');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Payment failed: ${response.message}")),
    );
  }

  void _startPurchase() {
    final razorpayKey = dotenv.env['RAZORPAY_KEY_ID'];
    if (razorpayKey == null || razorpayKey.isEmpty) {
      debugPrint('⚠️ Razorpay key missing in .env');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Razorpay key missing. Please check .env')),
      );
      return;
    }

    final amountPaise = widget.price * 100;

    debugPrint('🛒 Starting purchase for Portal ${widget.portalIndex}');
    debugPrint('🔑 Razorpay Key: $razorpayKey');
    debugPrint('💰 Amount in Paise: $amountPaise');

    _razorpayService.openCheckout(
      keyId: razorpayKey,
      amount: amountPaise,
      name: "Portal ${widget.portalIndex}",
    );
  }

  @override
  void dispose() {
    _razorpayService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_isUnlocked) {
      Future.microtask(() {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const CosmicNexusScreen()),
        );
      });
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Portal ${widget.portalIndex}"),
        backgroundColor: Colors.deepPurple,
      ),
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Unlock Portal ${widget.portalIndex} for ₹${widget.price}",
              style: const TextStyle(color: Colors.white, fontSize: 20),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _startPurchase,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purpleAccent,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                textStyle: const TextStyle(fontSize: 18),
              ),
              child: const Text("Buy Now"),
            ),
          ],
        ),
      ),
    );
  }
}