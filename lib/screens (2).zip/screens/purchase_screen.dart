import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

// Screens & Services
import '../services/razorpay_service.dart';
import 'individual_portal_screen.dart';
import 'cosmic_nexus_screen.dart';

// Widgets
import '../widgets/portal_card.dart';
import '../widgets/bundle_card.dart';

class PurchaseScreen extends StatefulWidget {
  const PurchaseScreen({Key? key}) : super(key: key);

  @override
  State<PurchaseScreen> createState() => _PurchaseScreenState();
}

class _PurchaseScreenState extends State<PurchaseScreen> {
  final RazorpayService _razorpayService = RazorpayService();
  final User? user = FirebaseAuth.instance.currentUser;

  final List<int> portalPrices = [199, 249, 299, 349, 399, 449, 499, 499];
  final int bundlePrice = 1899;

  List<String> _unlockedPortals = [];
  bool _isFetchingUnlocks = true;

  @override
  void initState() {
    super.initState();
    _razorpayService.init(
      onSuccess: _handlePaymentSuccess,
      onError: _handlePaymentError,
    );
    _fetchUnlockedPortals();
  }

  Future<void> _fetchUnlockedPortals() async {
    final uid = user?.uid;
    if (uid == null) return;

    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    final data = doc.data();
    if (data != null && data['unlockedPortals'] != null) {
      setState(() {
        _unlockedPortals = List<String>.from(data['unlockedPortals']);
        _isFetchingUnlocks = false;
      });
    } else {
      setState(() {
        _unlockedPortals = [];
        _isFetchingUnlocks = false;
      });
    }
  }

  @override
  void dispose() {
    _razorpayService.dispose();
    super.dispose();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final unlocks = [
      ...List.generate(8, (i) => 'portal_${i + 1}'),
      'portal_infinity',
      'ritual_bonus_1',
      'ritual_bonus_2',
      'wallpaper_pack',
      'cosmic_theme',
      'advanced_practices',
      'infinite_scroll',
    ];

    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;

    try {
      await FirebaseFirestore.instance.collection('users').doc(userId).set({
        'unlockedPortals': FieldValue.arrayUnion(unlocks),
      }, SetOptions(merge: true));

      debugPrint("✅ Firestore updated with unlocks: $unlocks");

      await _fetchUnlockedPortals(); // Refresh UI
      _showCelebrationModal(); // Ritualize the moment
    } catch (e) {
      debugPrint("❌ Firestore update failed: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('⚠️ Failed to update unlocks.')),
        );
      }
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('⚠️ Payment failed: ${response.message}')),
      );
    }
  }

  void _startBundlePurchase() {
    final hasBundle = _unlockedPortals.length >= 8;
    if (hasBundle) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const CosmicNexusScreen()));
      return;
    }

    final razorpayKey = dotenv.env['RAZORPAY_KEY_ID'];
    if (razorpayKey == null || razorpayKey.isEmpty) {
      debugPrint('⚠️ Razorpay key missing in .env');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Razorpay key missing. Please check .env')),
      );
      return;
    }

    final amountInPaise = bundlePrice * 100;

    debugPrint('🛒 Starting bundle purchase');
    _razorpayService.openCheckout(
      keyId: razorpayKey,
      amount: amountInPaise,
      name: 'Portal8 Cosmic Bundle',
    );
  }

  void _showCelebrationModal() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.of(context).pop(); // Close modal
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const CosmicNexusScreen()),
          );
        });

        return Center(
          child: AnimatedScale(
            scale: 1.0,
            duration: const Duration(milliseconds: 600),
            curve: Curves.elasticOut,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.deepPurple.shade900,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: Colors.purpleAccent, blurRadius: 24),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.auto_awesome, color: Colors.amberAccent, size: 48),
                  SizedBox(height: 16),
                  Text(
                    '🌌 Cosmic Bundle Unlocked!',
                    style: TextStyle(
                      fontSize: 22,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'Your mythic journey begins now.\nExplore all portals freely.',
                    style: TextStyle(color: Colors.white70, fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _portalSwiper() {
    if (_isFetchingUnlocks) {
      return const Center(child: CircularProgressIndicator());
    }

    return SizedBox(
      height: 180,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: portalPrices.length,
        itemBuilder: (context, index) {
          final portalNumber = index + 1;
          final price = portalPrices[index];
          final portalId = 'portal_$portalNumber';
          final isUnlocked = _unlockedPortals.contains(portalId);

          return PortalCard(
            portalNumber: portalNumber,
            price: price,
            isUnlocked: isUnlocked,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => IndividualPortalScreen(
                    portalIndex: portalNumber,
                    price: price,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _benefit(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        text,
        style: const TextStyle(fontSize: 16, color: Colors.white70),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasBundle = _unlockedPortals.length >= 8;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const FittedBox(
          fit: BoxFit.scaleDown,
          child: Text('✨ Unlock Your Awakening'),
        ),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  '🪐 Choose Your Path',
                  style: TextStyle(
                    fontSize: 26,
                    color: Colors.purpleAccent,
                    fontWeight: FontWeight.bold,
                    shadows: [Shadow(blurRadius: 12, color: Colors.purple, offset: Offset(0, 0))],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            _portalSwiper(),
            const SizedBox(height: 24),
            BundleCard(
              price: bundlePrice,
              isUnlocked: hasBundle,
              onTap: _startBundlePurchase,
            ),
            const SizedBox(height: 40),
            const Text(
              "🌟 Why Begin?",
              style: TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            _benefit("🌿 Deep relaxation and inner peace"),
            _benefit("✨ Bliss beyond thought and form"),
            _benefit("🛡️ Freedom from anxiety and depression"),
            _benefit("🌞 A life lived fully, not just survived"),
            _benefit("🌀 A mythic journey that evolves with you"),
            const SizedBox(height: 32),
            Center(
              child: Text(
                hasBundle
                    ? "✨ All portals are now yours. Enter the Nexus."
                    : "💫 Unlock all portals with the Cosmic Bundle.",
                style: TextStyle(
                  fontSize: 16,
                  color: hasBundle ? Colors.greenAccent : Colors.white70,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 24),
            if (hasBundle)
              Center(
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CosmicNexusScreen()),
                    );
                  },
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text("Enter Cosmic Nexus"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.greenAccent,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
