import 'package:flutter/material.dart';
import 'package:portal8/utils/app_constants.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:portal8/utils/starfield_background.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  final List<OnboardingPage> _onboardingPages = const [
    OnboardingPage(
      imagePath: 'assets/images/onboarding_1.png',
      title: 'Welcome to Portal 8',
      description: 'Your journey to self-discovery and consciousness begins now. Explore the illusions that shape your reality.',
    ),
    OnboardingPage(
      imagePath: 'assets/images/onboarding_2.png',
      title: 'Embrace the Journey',
      description: 'Each portal is a new challenge, a new lesson. Step through and unlock your full potential.',
    ),
    OnboardingPage(
      imagePath: 'assets/images/onboarding_3.png',
      title: 'Connect and Grow',
      description: 'Join a community of fellow explorers. Share your insights and grow together.',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StarfieldBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: PageView(
                  controller: _pageController,
                  children: _onboardingPages,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 24.0),
                child: SmoothPageIndicator(
                  controller: _pageController,
                  count: _onboardingPages.length,
                  effect: ExpandingDotsEffect(
                    dotColor: kStarlightBlue.withOpacity(0.4),
                    activeDotColor: kPortalPurple,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pushReplacementNamed('/login');
                      },
                      child: Text(
                        'Skip',
                        style: kBodyTextStyle.copyWith(color: kStarlightBlue),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        if (_pageController.page == _onboardingPages.length - 1) {
                          Navigator.of(context).pushReplacementNamed('/login');
                        } else {
                          _pageController.nextPage(
                            duration: const Duration(milliseconds: 400),
                            curve: Curves.easeInOut,
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kAccentNeonGreen,
                        foregroundColor: kCosmicBlack,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                      child: Text(
                        'Next',
                        style: kButtonTextStyle.copyWith(color: kCosmicBlack),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class OnboardingPage extends StatelessWidget {
  final String imagePath;
  final String title;
  final String description;

  const OnboardingPage({
    super.key,
    required this.imagePath,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          imagePath,
          height: 250,
        ),
        const SizedBox(height: 32),
        Text(
          title,
          style: kTitleTextStyle,
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Text(
            description,
            style: kSubtitleTextStyle.copyWith(color: kNebulaWhite.withOpacity(0.7)),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}
